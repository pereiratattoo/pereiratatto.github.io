
let products = JSON.parse(localStorage.getItem("products") || "[]");

const container = document.getElementById("products");

products.forEach(p=>{
container.innerHTML += `
<div class="product">
<h3>${p.name}</h3>
<p>R$ ${p.price}</p>
<a class="btn" href="https://wa.me/5512997325292?text=Quero comprar ${p.name}">Comprar</a>
</div>`;
});
